# Winnie Kwong
# Professor Foster
# February 27th, 2023
# CS-210 - Programming Languages
# Module One Assignment

# outputs Hello World!
print("Hello World!\n")
