// Winnie Kwong
// Professor Foster
// February 27th, 2023
// CS - 210 - Programming Languages
// Module One Assignment

#include <iostream>
using namespace std;
int main() {
	// output Hello World! and end with a new line
	cout << "Hello World!" << endl;
	return 0;
}